import turtle
import pandas

# --- Setup the screen
image = "./blank_states_img.gif"
screen = turtle.Screen()
screen.title("U.S.A States Guessing Game")
screen.setup(width=728, height=495)
screen.addshape(image)
turtle.shape(image)

source_data = pandas.read_csv("./50_states.csv")
# print(source_data)

score = 0
keep_going = True

def player_question():
    answer_state = screen.textinput(title=f"Guess the state. {score}/50", prompt="Name another state:").title()
    return answer_state


while keep_going is True:
    player_answer = player_question()
    for state_name in range(len(source_data.state)):
        if player_answer == source_data.state[state_name]:
            print("Correct")
            score += 1
            print(player_answer, source_data["state"].source_data["x"], source_data["state"].source_data["y"])
            # logo = turtle.write(player_answer, align="center")
            # logo = turtle.goto(int(source_data.x), int(source_data.y))
            
            
            #self.write(self.l_score, align="center", font=FONT)
            #self.goto(100, 200)
            
            if score == 50:
                print("You win")
                keep_going = False
        else:
            print("error")
            print(player_answer)
        


#data[data.day == "Monday"]
# print(answer_state)


#turtle.mainloop()

# def get_mouse_click_coor(x, y):
#     print(x, y)
# turtle.onscreenclick(get_mouse_click_coor)